
console.log("Thanks for giving the OS and its version");

let str = prompt("Enter your phome and its version with space in b/w");

//console.log(str.split(" "));

str1 =str.split(" ");

console.log(`The OS name is ${str1[0]} and version is ${str1[1]}`);

